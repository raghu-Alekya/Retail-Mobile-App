import { Component, OnInit } from '@angular/core';
import { AuthService } from 'src/app/services/auth/auth.service';

@Component({
  selector: 'app-users-list',
  templateUrl: './users-list.page.html',
  styleUrls: ['./users-list.page.scss'],
})
export class UsersListPage implements OnInit {

  users: any[] = [];
  filteredUsers: any[] = [];

  constructor(private authService: AuthService) {}

  ngOnInit() {
    this.loadUsers();
  }

  async loadUsers() {
    try {
      const data = await this.authService.getUsers('', 1, 20);

      console.log('RAW USERS:', data);

      this.users = Array.isArray(data.users)
        ? data.users.filter((user: any) =>
            user.roles && !user.roles.includes('customer')
          )
        : [];

      this.filteredUsers = [...this.users];

    } catch (error) {
      console.error('Error loading users', error);
    }
  }

  onSearch(event: any) {
    const value = event.target.value.toLowerCase();

    this.users = this.filteredUsers.filter(user =>
      user.name?.toLowerCase().includes(value) ||
      user.id?.toString().includes(value)
    );
  }

  getRoleLabel(roles: string[]) {
    if (!roles || roles.length === 0) return '';
    return roles[0].replace('_', ' ');
  }
}