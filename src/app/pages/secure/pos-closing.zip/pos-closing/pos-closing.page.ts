import { Component, OnInit } from '@angular/core';
import { AuthService } from 'src/app/services/auth/auth.service';

@Component({
  selector: 'app-pos-closing',
  templateUrl: './pos-closing.page.html',
  styleUrls: ['./pos-closing.page.scss'],
})
export class PosClosingPage implements OnInit {

  loading = false;
  isFilterModalOpen = false;
selectedDateText = '';
filterType: 'date' | 'range' = 'date';
selectedDate = '';

fromDate = '';

toDate = '';

  posClosingData: any = {
    total_orders: 0,
    total_orders_amount: 0,
    cancelled_orders: 0,
    refunded_orders_amount: 0,
    payouts: 0,
    void_items: 0,
    cash: 0,
    card: 0,
    ebt: 0
  };

  constructor(
    private authService: AuthService
  ) { }

  ngOnInit() {
  const today = new Date();

  const startDate = new Date(today);
  startDate.setMonth(today.getMonth() - 1); // Example: last 1 month

  this.loadPosClosing(
    this.formatDate(startDate),
    this.formatDate(today)
  );
}

private formatDate(date: Date): string {
  return date.toISOString().split('T')[0];
}

  openDateFilter() {
  this.isFilterModalOpen = true;
}

async applyFilter() {

  let startDate = '';
  let endDate = '';

  if (this.filterType === 'date') {
    startDate = this.selectedDate;
    endDate = this.selectedDate;
    this.selectedDateText = this.selectedDate;
  } else {
    startDate = this.fromDate;
    endDate = this.toDate;
    this.selectedDateText = `${this.fromDate} - ${this.toDate}`;
  }

  console.log('Start Date:', startDate);
  console.log('End Date:', endDate);

  await this.loadPosClosing(startDate, endDate);

  this.isFilterModalOpen = false;
}

onDateChange(value: string) {
  console.log('Date Changed:', value);
  this.selectedDate = value;
}

  async loadPosClosing(startDate: string, endDate: string) {

  this.loading = true;

  try {

    const response = await this.authService.getPosClosing(startDate, endDate);

    if (response.success) {
      this.posClosingData = response.data;
    }

  } catch (error) {
    console.error(error);

  } finally {
    this.loading = false;
  }

}

}