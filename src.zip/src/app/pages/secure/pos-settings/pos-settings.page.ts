import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ToastController } from '@ionic/angular';
import { AuthService } from 'src/app/services/auth/auth.service';
import { AlertController } from '@ionic/angular';

@Component({
    selector: 'app-pos-settings',
    templateUrl: './pos-settings.page.html',
    styleUrls: ['./pos-settings.page.scss'],
    standalone: false
})
export class PosSettingsPage implements OnInit {

  form!: FormGroup;
  user: any;
  isLoadingSettings = false;
  emailError: string = '';
  phoneError: string = '';
  isAddingCategory = false;
  isAddingTag = false;
  storeNameError: string = '';
cityError: string = '';
stateError: string = '';
emailEmojiError: string = '';
addressError: string = '';
categoryError: string = '';
tagError: string = '';

  settings: any = {
    address: {
      pinaka_pos_name: '',
      pinaka_pos_email: '',
      pinaka_pos_phone: '',
      pinaka_pos_business_address: '',
      pinaka_pos_business_city: '',
      pinaka_pos_business_state: '',
      pinaka_pos_business_postcode: ''
    },
    enableTaxes: false,
    enableCoupons: false,
    sequentialCoupons: false,
    enable_safes: false,
    enable_safes_drop: false,
    enable_cashback: false,
    enable_service_charge: false,
    enable_loyalty_points: false,
    currency_symbol: ''
  };
  categories: { name: string; id: number }[] = [];
  tags: { id: number; name: string }[] = [];

  newCategory = '';
  newTag = '';
  currencies: any = {};

  constructor(
    private fb: FormBuilder,
    private authService: AuthService,
    private toastController: ToastController,
    private alertController: AlertController
  ) {}

  validateEmail() {
  const email = this.settings.address.pinaka_pos_email;

  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

  if (email && !emailRegex.test(email)) {
    this.emailError = 'Please enter a valid email address';
  } else {
    this.emailError = '';
  }
}

onPhoneInput(event: any) {
  let value = event.target.value || '';

  value = value.replace(/\D/g, '');
  value = value.substring(0, 10);

  this.settings.address.pinaka_pos_phone = value;

  this.validatePhone();
}

validatePhone() {
  const phone = this.settings.address.pinaka_pos_phone || '';

  if (phone.length === 0) {
    this.phoneError = '';
  } else if (phone.length !== 10) {
    this.phoneError = 'Phone number must be exactly 10 digits';
  } else {
    this.phoneError = '';
  }
}

  /* ================= INIT ================= */

  ngOnInit() {
    this.user = this.authService.getCurrentUser();

    this.form = this.fb.group({
      enable_safes: [false],
      enable_safes_drop: [false],
      currency: ['', Validators.required],
      enable_cashback: [false],
      enable_service_charge: [false],
      enable_loyalty_points: [false]
    });
  }

  /**
   * IMPORTANT:
   * Runs every time you enter screen
   */
  ionViewWillEnter() {
    this.loadSettings();
    this.loadCategories();
    this.loadTags();
  }

  /* ================= LOAD SETTINGS ================= */

  async loadSettings() {
    this.isLoadingSettings = true;


    try {
      const res = await this.authService.getCashSettings();
      const data = res?.data?.data || res?.data || res;

      if (!data) return;

      const toBool = (v: any) => v === true || v === 1 || v === "1";

      this.settings.address = {
        pinaka_pos_name: data.shop_info.pinaka_pos_name,
        pinaka_pos_email: data.shop_info.pinaka_pos_email,
        pinaka_pos_phone: data.shop_info.pinaka_pos_phone,
        pinaka_pos_business_address: data.shop_info.pinaka_pos_business_address,
        pinaka_pos_business_city: data.shop_info.pinaka_pos_business_city,
        pinaka_pos_business_state: data.shop_info.pinaka_pos_business_state,
        pinaka_pos_business_postcode: data.shop_info.pinaka_pos_business_postcode
      }

      this.settings.enable_safes = toBool(data.enable_safes);
      this.settings.enable_safes_drop = toBool(data.enable_safes_drop);

      this.settings.enableTaxes = toBool(data.tax_enabled);
      this.settings.enableCoupons = toBool(data.coupons_enabled);
      this.settings.sequentialCoupons = toBool(data.calc_sequential_coupons);

      this.settings.currency = data.selected_currency;
      this.currencies = data.currencies;

      setTimeout(() => {
        this.form.patchValue({
          currency: this.settings.currency
        });
      });

      this.settings.enable_cashback =
        toBool(data.pinaka_pos_cashback_settings?.enabled);

      this.settings.enable_service_charge =
        toBool(data.pinaka_pos_service_charge_settings?.enabled);

      this.settings.enable_loyalty_points =
        !!data.pinaka_pos_enable_loyalty_points;

      this.settings.currency_symbol = data.currency_symbol || '';

    } catch (err) {
      console.error('Settings load failed', err);
    } finally {
      setTimeout(() => {
        this.isLoadingSettings = false;
      }, 300);
    }
  }


  async saveAddress() {

    if (
  this.storeNameError ||
  this.emailEmojiError ||
  this.addressError ||
  this.cityError ||
  this.stateError
) {
  await this.presentToast(
    'Please remove emojis from the fields',
    'danger'
  );
  return;
}
    this.validateEmail(); // 👈 run validation first
    this.validatePhone();

    if (this.emailError || this.phoneError) {
      await this.presentToast(
        this.emailError || this.phoneError,
        'danger'
      );
      return;
    }
    const payload = {
      shop_address: {
        pinaka_pos_name: this.settings.address.pinaka_pos_name,
        pinaka_pos_email: this.settings.address.pinaka_pos_email,
        pinaka_pos_phone: this.settings.address.pinaka_pos_phone,
        pinaka_pos_business_address: this.settings.address.pinaka_pos_business_address,
        pinaka_pos_business_city: this.settings.address.pinaka_pos_business_city,
        pinaka_pos_business_state: this.settings.address.pinaka_pos_business_state,
        pinaka_pos_business_postcode: this.settings.address.pinaka_pos_business_postcode
      },
    };
    // 🔌 API call
    try {
      const response = await this.authService.saveBussinessInfo(payload);
       // ✅ SUCCESS
      const message = 
        response?.data?.message ||
        'Settings saved successfully';

      await this.presentToast(message, 'success');

    } catch (err: any) {

      // ✅ AXIOS ERROR HANDLING
      const errorMessage =
        err?.response?.data?.message ||
        err?.response?.data?.data?.message ||
        'Failed to save settings';

      await this.presentToast(errorMessage, 'danger');
    }
  }
  async onCurrencyChange() {

    if (this.isLoadingSettings) return;   // ✅ prevent auto trigger

    const currency = this.form.value.currency;

    try {
      await this.authService.updateStoreCurrency(currency);

      this.presentToast('Currency updated successfully');

    } catch (error) {
      console.error(error);
      this.presentToast('Failed to update', 'danger');
    }
  }
  async loadCategories() {
    try {
      const res = await this.authService.getCategories(1, 100);
      this.categories = res.map((cat: any) => ({ name: cat.name, id: cat.id }));
    } catch (err) {
      console.error('Failed to load product categories', err);
    }
  }

  async addCategory() {

    if (this.categoryError) {
    this.presentToast('Please remove emojis from category name', 'danger');
    return;
  }

  if (this.isAddingCategory) return;

  const name = this.newCategory.trim();

  if (!name) return;

  // ✅ DUPLICATE CHECK
  const alreadyExists = this.categories.some(
    cat => cat.name.toLowerCase() === name.toLowerCase()
  );

  if (alreadyExists) {
    await this.presentToast('Category already exists', 'warning');
    return;
  }

  this.isAddingCategory = true;

  const payload = { name };

  try {
    const response = await this.authService.saveCategory(payload);

    this.categories.push({
      id: response.id,
      name: response.name
    });

    this.newCategory = '';

    await this.presentToast('Category created successfully', 'success');

  } catch (err) {
    console.error(err);
    await this.presentToast('Failed to create category', 'danger');
  } finally {
    this.isAddingCategory = false;
  }
}

  async removeCategory(category_id: number) {

    const alert = await this.alertController.create({
      header: 'Delete Category',
      message: 'Are you sure you want to delete this category?',
      buttons: [
        {
          text: 'Cancel',
          role: 'cancel'
        },
        {
          text: 'Delete',
          role: 'destructive',
          handler: () => {
            this.deleteCategory(category_id);
          }
        }
      ]
    });

    await alert.present();
  }


  async deleteCategory(category_id:number){

    try {

      await this.authService.deleteCategory(category_id);

      this.categories = this.categories.filter(
        cat => cat.id !== category_id
      );

      await this.presentToast('Category deleted successfully','success');

    } catch (err) {

      console.error(err);

      await this.presentToast('Failed to delete category','danger');

    }

  }
  /* ================= TOAST ================= */

  async presentToast(message: string, color: any = 'success') {
    const toast = await this.toastController.create({
      message,
      duration: 2000,
      position: 'bottom',
      color
    });
    toast.present();
  }

  async loadTags() {
    try {
      const res = await this.authService.getTags();
      this.tags = res.map((tag: any) => ({
  id: tag.id,
  name: tag.name
}));
    } catch (err) {
      console.error('Failed to load product tags', err);
    }
  }

  /* =====================
     PRODUCT TAGS
     ===================== */

  async addTag() {

    if (this.tagError) {
    this.presentToast('Please remove emojis from tag name', 'danger');
    return;
  }

  if (this.isAddingTag) return;

  const name = this.newTag.trim();

  if (!name) return;

  // ✅ DUPLICATE CHECK
  const alreadyExists = this.tags.some(
    tag => tag.name.toLowerCase() === name.toLowerCase()
  );

  if (alreadyExists) {
    await this.presentToast('Tag already exists', 'warning');
    return;
  }

  this.isAddingTag = true;

  const payload = { name };

  try {
    const res = await this.authService.createTag(payload);

    this.tags.push({
      id: res.id,
      name: res.name
    });

    this.newTag = '';

    await this.presentToast('Tag created successfully','success');

  } catch (err) {
    console.error(err);
    await this.presentToast('Failed to create tag','danger');
  } finally {
    this.isAddingTag = false;
  }
}

  async removeTag(tag: { id: number; name: string }) {

    const alert = await this.alertController.create({
      header: 'Delete Tag',
      message: 'Are you sure you want to delete this tag?',
      buttons: [
        {
          text: 'Cancel',
          role: 'cancel'
        },
        {
          text: 'Delete',
          role: 'destructive',
          handler: () => {
            this.deleteTag(tag); // ✅ use id
          }
        }
      ]
    });

    await alert.present();
  }

  async deleteTag(tag: any){

  try {

    await this.authService.deleteTag(tag.id);

    this.tags = this.tags.filter(t => t.id !== tag.id);

    await this.presentToast('Tag deleted successfully','success');

  } catch (err) {

    console.error(err);

    await this.presentToast('Failed to delete tag','danger');

  }

}

  /* ================= TOGGLE HANDLER ================= */

  async onToggleChange(event: any, key: string) {

    if (this.isLoadingSettings) return;

    const checked = event.detail.checked;
    this.settings[key] = checked;

    const value = checked ? 1 : 0;

    const apiMap: any = {

      enable_safes: () =>
        this.authService.updateEnableSafes({ enable_safes: value }),

      enable_safes_drop: () =>
        this.authService.updateEnableSafesDrop({ enable_safes_drop: value }),

      enable_cashback: () =>
        this.authService.updateCashback({ enable_cashback: value }),

      enable_service_charge: () =>
        this.authService.updateServiceCharge({ enable_service_charge: value }),

      enable_loyalty_points: () =>
        this.authService.updateLoyaltyPoints({
          enable_loyalty_points: checked ? 'yes' : 'no'
        }),

        enableTaxes: () =>
        this.authService.enableTaxes({
          enable_taxes: value
        }),

        enableCoupons: () =>
        this.authService.enableCoupons({
          enable_coupons: value
        }),

        sequentialCoupons: () =>
        this.authService.sequentialCoupons({
          coupon_sequential: value
        }),
    };

    try {
      const res = await apiMap[key]();
     this.presentToast(
  key === 'enableTaxes'
    ? checked ? 'Taxes enabled' : 'Taxes disabled'
    : (checked ? 'Enabled' : 'Disabled')
);
    } catch (error) {
      console.error(error);
      this.presentToast('Failed to update', 'danger');
    }
  }
  /* ================= SAVE CASH SETTINGS ================= */

  async save() {
    if (this.form.invalid) return;

    try {
      await this.authService.saveCashSettings(this.form.value);
      this.presentToast('Settings saved');
    } catch {
      this.presentToast('Failed to save', 'danger');
    }
  }

  signOut() {
    this.authService.logout();
  }

  async editCategory(category: any) {

    const alert = await this.alertController.create({
      header: 'Edit Category',
      inputs: [
        {
          name: 'name',
          type: 'text',
          value: category.name
        }
      ],
      buttons: [
        { text: 'Cancel', role: 'cancel' },
        {
  text: 'Update',
  handler: async (data) => {

    const emojiRegex = /[\p{Emoji_Presentation}\p{Extended_Pictographic}]/gu;

if (emojiRegex.test(data.name)) {
  await this.presentToast(
    'Emojis are not allowed in category name',
    'danger'
  );
  return false; // keep alert open
}

    const newName = data.name.trim();

    if (!newName) return false;

    // ✅ DUPLICATE CHECK (exclude current category)
    const alreadyExists = this.categories.some(
      cat =>
        cat.id !== category.id &&   // 👈 important (ignore same item)
        cat.name.toLowerCase() === newName.toLowerCase()
    );

    if (alreadyExists) {
      await this.presentToast('Category already exists', 'warning');
      return false; // ❌ stop alert from closing
    }

    try {

      const res = await this.authService.updateCategory(
        category.id,
        { name: newName, slug: this.createSlug(newName) }
      );

      category.name = res.name;

      this.presentToast('Category updated successfully','success');

    } catch (error) {

      console.error(error);

      this.presentToast('Failed to update category','danger');

    }

  }
}
      ]
    });

    await alert.present();
  }

  async editTag(tag: any) {

    const alert = await this.alertController.create({
      header: 'Edit Tag',
      inputs: [
        {
          name: 'name',
          type: 'text',
          value: tag.name
        }
      ],
      buttons: [
        { text: 'Cancel', role: 'cancel' },
        {
  text: 'Update',
  handler: async (data) => {

    const emojiRegex = /[\p{Emoji_Presentation}\p{Extended_Pictographic}]/gu;

  if (emojiRegex.test(data.name)) {
    await this.presentToast(
      'Emojis are not allowed in tag name',
      'danger'
    );
    return false;
  }

    const newName = data.name.trim();

    if (!newName) return false;

    // ✅ DUPLICATE CHECK (ignore current tag)
    const alreadyExists = this.tags.some(
      t =>
        t.id !== tag.id &&   // 👈 important
        t.name.toLowerCase() === newName.toLowerCase()
    );

    if (alreadyExists) {
      await this.presentToast('Tag already exists', 'warning');
      return false; // ❌ keep alert open
    }

    try {

      const res = await this.authService.updateTag(
        tag.id,
        { name: newName, slug: this.createSlug(newName) }
      );

      tag.name = res.name;

      this.presentToast('Tag updated successfully','success');

    } catch (error) {

      console.error(error);

      this.presentToast('Failed to update tag','danger');

    }

  }
}
      ]
    });

    await alert.present();
  }
  
  createSlug(name: string): string {
    return name
      .toLowerCase()
      .trim()
      .replace(/[^a-z0-9\s-]/g, '')   // remove special chars
      .replace(/\s+/g, '-')           // replace spaces with -
      .replace(/-+/g, '-');           // remove duplicate -
  }

  onPostcodeInput(event: any) {
  let value = event.target.value || '';

  value = value.replace(/\D/g, ''); // numbers only
  value = value.substring(0, 6);    // max 6 digits

  this.settings.address.pinaka_pos_business_postcode = value;
}

onStoreNameInput(event: any) {
  const value = event.target.value || '';

  const emojiRegex = /[\p{Emoji_Presentation}\p{Extended_Pictographic}]/gu;

  if (emojiRegex.test(value)) {
    this.storeNameError = 'Emojis are not allowed';
  } else {
    this.storeNameError = '';
  }

  this.settings.address.pinaka_pos_name = value.replace(emojiRegex, '');
}

onEmailInput(event: any) {
  const value = event.target.value || '';

  const emojiRegex = /[\p{Emoji_Presentation}\p{Extended_Pictographic}]/gu;

  if (emojiRegex.test(value)) {
    this.emailEmojiError = 'Emojis are not allowed';
  } else {
    this.emailEmojiError = '';
  }

  this.settings.address.pinaka_pos_email =
    value.replace(emojiRegex, '');

  this.validateEmail();
}

onCityInput(event: any) {
  const value = event.target.value || '';

  const emojiRegex = /[\p{Emoji_Presentation}\p{Extended_Pictographic}]/gu;

  if (emojiRegex.test(value)) {
    this.cityError = 'Emojis are not allowed';
  } else {
    this.cityError = '';
  }

  this.settings.address.pinaka_pos_business_city =
    value.replace(emojiRegex, '');
}

onStateInput(event: any) {
  const value = event.target.value || '';

  const emojiRegex = /[\p{Emoji_Presentation}\p{Extended_Pictographic}]/gu;

  if (emojiRegex.test(value)) {
    this.stateError = 'Emojis are not allowed';
  } else {
    this.stateError = '';
  }

  this.settings.address.pinaka_pos_business_state =
    value.replace(emojiRegex, '');
}

onAddressInput(event: any) {
  const value = event.target.value || '';

  const emojiRegex = /[\p{Emoji_Presentation}\p{Extended_Pictographic}]/gu;

  if (emojiRegex.test(value)) {
    this.addressError = 'Emojis are not allowed';
  } else {
    this.addressError = '';
  }

  this.settings.address.pinaka_pos_business_address =
    value.replace(emojiRegex, '');
}

onCategoryInput(event: any) {
  const value = event.target.value || '';

  const emojiRegex = /[\p{Emoji_Presentation}\p{Extended_Pictographic}]/gu;

  if (emojiRegex.test(value)) {
    this.categoryError = 'Emojis are not allowed';
  } else {
    this.categoryError = '';
  }

  this.newCategory = value.replace(emojiRegex, '');
}

onTagInput(event: any) {
  const value = event.target.value || '';

  const emojiRegex = /[\p{Emoji_Presentation}\p{Extended_Pictographic}]/gu;

  if (emojiRegex.test(value)) {
    this.tagError = 'Emojis are not allowed';
  } else {
    this.tagError = '';
  }

  this.newTag = value.replace(emojiRegex, '');
}
}